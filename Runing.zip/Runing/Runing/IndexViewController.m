//
//  IndexViewController.m
//  Runing
//
//  Created by 王佳佳 on 2017/3/2.
//  Copyright © 2017年 王佳佳. All rights reserved.
//

#import "IndexViewController.h"
#import "ViewController.h"
#import "ReplaceViewController.h"
#import "LoginViewController.h"


@interface IndexViewController ()

@end

@implementation IndexViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor=[UIColor whiteColor];
    [self creatUI];
}
#pragma mark - 搭建页面
-(void)creatUI{
    
    float width=[UIScreen mainScreen].bounds.size.width/3;
    float orginY=[UIScreen mainScreen].bounds.size.height/6;
    UIImageView *imageView=[[UIImageView alloc] initWithFrame:CGRectMake(width, orginY, width, width)];
    imageView.layer.cornerRadius=width/2;
    imageView.layer.masksToBounds=YES;
    [self.view addSubview:imageView];
    imageView.contentMode=UIViewContentModeScaleAspectFill;
    imageView.image=[UIImage imageNamed:@"icon.png"];
    
    UIButton *setButton=[UIButton buttonWithType:UIButtonTypeCustom];
    setButton.frame=CGRectMake(width, orginY+width+40, width, 35);
    [setButton setTitle:@"设置手势密码" forState:UIControlStateNormal];
    [setButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [setButton addTarget:self action:@selector(setPassword) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:setButton];
    
    UIButton *changebutton=[UIButton buttonWithType:UIButtonTypeCustom];
    changebutton.frame=CGRectMake(width, setButton.frame.origin.y+setButton.frame.size.height+20, width, 35);
     [changebutton addTarget:self action:@selector(changePassword) forControlEvents:UIControlEventTouchUpInside];
    [changebutton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [changebutton setTitle:@"重置手势密码" forState:UIControlStateNormal];
    [self.view addSubview:changebutton];
    
    UIButton *LoginButton=[UIButton buttonWithType:UIButtonTypeCustom];
    LoginButton.frame=CGRectMake(width, changebutton.frame.origin.y+changebutton.frame.size.height+20, width, 35);
    [LoginButton addTarget:self action:@selector(login) forControlEvents:UIControlEventTouchUpInside];
    [LoginButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [LoginButton setTitle:@"登录" forState:UIControlStateNormal];
    [self.view addSubview:LoginButton];
    
    
    UILabel *remarkLable=[[UILabel alloc] initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height-100, [UIScreen mainScreen].bounds.size.width, 35)];
    remarkLable.text=@"注：设置密码手势密码即可清空上次设置的密码";
    remarkLable.font=[UIFont systemFontOfSize:14];
    remarkLable.textColor=[UIColor lightGrayColor];
    [self.view addSubview:remarkLable];
    
}
#pragma mark - 设置密码
-(void)setPassword
{
    ViewController *view=[[ViewController alloc] init];
    UINavigationController *una=[[UINavigationController alloc] initWithRootViewController:view];
    [self presentViewController:una animated:YES completion:nil];
    
}
#pragma mark - 登录
-(void)login
{
    LoginViewController *view=[[LoginViewController alloc] init];
    UINavigationController *una=[[UINavigationController alloc] initWithRootViewController:view];
    [self presentViewController:una animated:YES completion:nil];
    
}
#pragma mark - 重置密码
-(void)changePassword
{
    ReplaceViewController *replace=[[ReplaceViewController alloc] init];
    UINavigationController *una=[[UINavigationController alloc] initWithRootViewController:replace];
    [self presentViewController:una animated:YES completion:^{
        
    }];

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
