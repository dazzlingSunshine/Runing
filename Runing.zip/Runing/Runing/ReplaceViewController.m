//
//  ReplaceViewController.m
//  Runing
//
//  Created by 王佳佳 on 2017/3/3.
//  Copyright © 2017年 王佳佳. All rights reserved.
//

#import "ReplaceViewController.h"
#import "GestureView.h"


#define ScreenWidth [UIScreen mainScreen].bounds.size.width
#define ScreenHeight [UIScreen mainScreen].bounds.size.height


@interface ReplaceViewController ()

@property(nonatomic,strong)UILabel *messageLabel;
@property(nonatomic,assign)NSString *replace;
@end

@implementation ReplaceViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor=[UIColor whiteColor];
    self.navigationItem.title=@"重置密码";
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"back"] style:UIBarButtonItemStylePlain target:self action:@selector(back)];
    self.replace=@"1";
    [self creatUI];
}
-(void)back
{
   [self.navigationController dismissViewControllerAnimated:YES completion:^{
            
     }];
}
-(void)creatUI{

    GestureView *gesture=[[GestureView alloc] initWithFrame:CGRectMake(0, 64, ScreenWidth, ScreenWidth)];
    [self.view addSubview:gesture];
    __weak typeof(self) weakSelf=self;
    gesture.drawGestureBlock=^(NSString *gestureCode)
    {
        [weakSelf dealDataWith:gestureCode];
        
    };
    
    self.messageLabel=[[UILabel alloc] initWithFrame:CGRectMake(0, ScreenHeight-104, ScreenWidth, 64)];
    self.messageLabel.textColor=[UIColor redColor];
    self.messageLabel.textAlignment=NSTextAlignmentCenter;
    self.messageLabel.text=@"请先验证登录密码";
    [self.view addSubview:self.messageLabel];


}

-(void)dealDataWith:(NSString *)code
{
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    NSString *gestureCode=[defaults objectForKey:@"gestureCode"];
    if (![gestureCode isEqualToString:code] && [self.replace isEqualToString:@"1"]) {
       self.messageLabel.text=@"输入登录密码错误";
       return;
    }
    if ([gestureCode isEqualToString:code] && [self.replace isEqualToString:@"1"]) {
        
        self.replace=@"2";
        self.messageLabel.text=@"登录密码验证成功";
        return;
    }
    if ([self.replace isEqualToString:@"2"]) {
        
        [defaults setObject:code forKey:@"gestureCode"];
        [defaults synchronize];
        self.messageLabel.text=@"密码重置成功";
        [self creatAlterView];
    }


}
-(void)creatAlterView
{
    UIAlertController *alter=[UIAlertController alertControllerWithTitle:nil message:@"密码重置成功" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *commitAction = [UIAlertAction  actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
       [self.navigationController dismissViewControllerAnimated:YES completion:^{
           
           
       }];
    }];
    [alter addAction:commitAction];
    [self presentViewController:alter animated:YES completion:nil];


}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
