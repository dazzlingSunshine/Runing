//
//  LoginViewController.m
//  Runing
//
//  Created by 王佳佳 on 2017/3/3.
//  Copyright © 2017年 王佳佳. All rights reserved.
//

#import "LoginViewController.h"
#define screenWidth [UIScreen mainScreen].bounds.size.width
#define screenHeight [UIScreen mainScreen].bounds.size.height

#import "GestureView.h"

@interface LoginViewController ()
@property(nonatomic,strong)UILabel *messageLabel;
@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    [self creatUI];
    
    self.navigationItem.title=@"登录";
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"back.png"] style:UIBarButtonItemStylePlain target:self action:@selector(back)];
    
}
-(void)back
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
-(void)creatUI
{
    GestureView *gestureView=[[GestureView alloc] initWithFrame:CGRectMake(0, 40, screenWidth, screenWidth)];
    [self.view addSubview:gestureView];
    __weak typeof(self) weakSelf=self;
    gestureView.drawGestureBlock=^(NSString *gestureCode)
    {
        NSLog(@"密码===%@",gestureCode);
        if (gestureCode.length<4) {
            
            weakSelf.messageLabel.text=@"最少连接4个点";
            return ;
        }
        [weakSelf dealDataWith:gestureCode];
    };
    
    self.messageLabel=[[UILabel alloc] initWithFrame:CGRectMake(0, screenHeight-104, screenWidth, 64)];
    self.messageLabel.textColor=[UIColor redColor];
    self.messageLabel.textAlignment=NSTextAlignmentCenter;
    [self.view addSubview:self.messageLabel];
    
    
}
#pragma mark - 数据处理
-(void)dealDataWith:(NSString *)code
{
    
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    NSString *gestureCode=[defaults objectForKey:@"gestureCode"];
    if (gestureCode.length==0) {
        self.messageLabel.text=@"请先设置手势密码";
        return;
    }
    if ([gestureCode isEqualToString:code] ) {
        
        self.messageLabel.text=@"登录成功";
        [self creatAlterViewWith:@"恭喜，登录成功"];
        
    }
    if (![gestureCode isEqualToString:code] ) {
        
        self.messageLabel.text=@"密码错误";
        
    }
       
}
-(void)creatAlterViewWith:(NSString *)string
{
    UIAlertController *alter=[UIAlertController alertControllerWithTitle:nil message:string preferredStyle:UIAlertControllerStyleAlert];
    [alter addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        [self.navigationController dismissViewControllerAnimated:YES completion:^{
            
        }];
    }]];
    [self presentViewController:alter animated:YES completion:nil];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
