//
//  GestureView.h
//  Runing
//
//  Created by 王佳佳 on 2017/3/3.
//  Copyright © 2017年 王佳佳. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GestureView : UIView
///按钮数组
@property(nonatomic,strong)NSMutableArray *buttonArray;
///选中按钮数组
@property(nonatomic,strong)NSMutableArray *selectButtonArray;
///起始点坐标
@property(nonatomic,assign)CGPoint startPoint;
///结束点坐标
@property(nonatomic,assign)CGPoint endPoint;
///画图
@property(nonatomic,strong)UIImageView *imageView;

///返回输入密码
@property(nonatomic,copy)void(^drawGestureBlock)(NSString *gestureCode);



@end
