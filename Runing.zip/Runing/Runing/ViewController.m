//
//  ViewController.m
//  Runing
//
//  Created by 王佳佳 on 2017/3/2.
//  Copyright © 2017年 王佳佳. All rights reserved.
//

#import "ViewController.h"
#define screenWidth [UIScreen mainScreen].bounds.size.width
#define screenHeight [UIScreen mainScreen].bounds.size.height

#import "GestureView.h"


@interface ViewController ()

///输入密码
@property(nonatomic,strong)NSString *password;
///信息提示
@property(nonatomic,strong)UILabel *messageLabel;



@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:@"gestureCode"];
    [defaults synchronize];
    
    self.view.backgroundColor=[UIColor whiteColor];
    [self creatUI];
    
    self.navigationItem.title=@"设置手势密码";
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"back.png"] style:UIBarButtonItemStylePlain target:self action:@selector(back)];

}
-(void)back
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
-(void)creatUI
{
    GestureView *gestureView=[[GestureView alloc] initWithFrame:CGRectMake(0, 40, screenWidth, screenWidth)];
    [self.view addSubview:gestureView];
    __weak typeof(self) weakSelf=self;
    gestureView.drawGestureBlock=^(NSString *gestureCode)
    {
        NSLog(@"密码===%@",gestureCode);
        if (gestureCode.length<4) {
            
            weakSelf.messageLabel.text=@"最少连接4个点";
            return ;
        }
        [weakSelf dealDataWith:gestureCode];
    };

    self.messageLabel=[[UILabel alloc] initWithFrame:CGRectMake(0, screenHeight-104, screenWidth, 64)];
    self.messageLabel.textColor=[UIColor redColor];
    self.messageLabel.textAlignment=NSTextAlignmentCenter;
    [self.view addSubview:self.messageLabel];
    
    
}
#pragma mark - 数据处理
-(void)dealDataWith:(NSString *)code
{
    
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    NSString *gestureCode=[defaults objectForKey:@"gestureCode"];
    if (gestureCode.length>0) {
        [defaults removeObjectForKey:@"gestureCode"];
        [defaults synchronize];
    }
    if (self.password.length==0) {
        self.password=code;
        self.messageLabel.text=@"请再次输入密码";
    }
    else
    {
        if ([code isEqualToString:self.password]) {
            [defaults setObject:self.password forKey:@"gestureCode"];
            [defaults synchronize];
            self.messageLabel.text=@"恭喜，密码设置成功！";
            [self creatAlterViewWith:@"恭喜，密码设置成功！"];
            
        }
        else
        {
            self.messageLabel.text=@"两次密码设置不一致";
            
        }
        
    }
    
    
}
-(void)creatAlterViewWith:(NSString *)string
{
    UIAlertController *alter=[UIAlertController alertControllerWithTitle:nil message:string preferredStyle:UIAlertControllerStyleAlert];
    [alter addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        [self.navigationController dismissViewControllerAnimated:YES completion:^{
            
        }];
    }]];
    [self presentViewController:alter animated:YES completion:nil];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
