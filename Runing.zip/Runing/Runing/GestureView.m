//
//  GestureView.m
//  Runing
//
//  Created by 王佳佳 on 2017/3/3.
//  Copyright © 2017年 王佳佳. All rights reserved.
//

#import "GestureView.h"
#define  span 20

@implementation GestureView

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    
    if (self) {
        
        float viewWidth=self.frame.size.width;
        float width=(viewWidth-4*span)/3;
        self.imageView=[[UIImageView alloc] initWithFrame:CGRectMake(0, 64+span, viewWidth,(width+span)*3)];
        [self addSubview:self.imageView];
        for (int i=0; i<9; i++) {
            UIButton *button=[UIButton buttonWithType:UIButtonTypeCustom];
            button.frame=CGRectMake(span*(i%3+1)+width*(i%3),span*(i/3+1)+width*(i/3), width, width);
            button.layer.cornerRadius=width/2.0;
            button.layer.masksToBounds=YES;
            [button setImage:[UIImage imageNamed:@"select"] forState:UIControlStateNormal];
            [button setImage:[UIImage imageNamed:@"selected"] forState:UIControlStateHighlighted];
            button.tag=100+i;
            button.userInteractionEnabled=NO;
            [self.buttonArray addObject:button];
            [self.imageView addSubview:button];
        }
    
    }

    return self;
}
-(NSMutableArray *)buttonArray
{
    if (!_buttonArray) {
        
       _buttonArray=[[NSMutableArray alloc] init];
    }

    return _buttonArray;
}
-(NSMutableArray *)selectButtonArray
{
    if (!_selectButtonArray) {
        
        _selectButtonArray=[[NSMutableArray alloc] init];
    }

    return _selectButtonArray;
}
#pragma mark - 画线
-(UIImage *)drawLine
{
    UIImage *image=nil;
    
    UIColor *lineColor=[UIColor colorWithRed:14/255.0 green:154/255.0 blue:239/255.0 alpha:1];
    UIGraphicsBeginImageContext(self.imageView.frame.size);
    CGContextRef context=UIGraphicsGetCurrentContext();
    ///画线的粗度
    CGContextSetLineWidth(context, 5);
    CGContextSetStrokeColorWithColor(context, lineColor.CGColor);
    ///起点
    CGContextMoveToPoint(context, self.startPoint.x, self.startPoint.y);
    ///从起点画线到选中的按键中心，并切换画线的起点
    for (UIButton *button in self.selectButtonArray) {
        
        CGPoint btnPo=button.center;
        CGContextAddLineToPoint(context, btnPo.x, btnPo.y);
        CGContextMoveToPoint(context, btnPo.x, btnPo.y);
    }
    ///画移动中的最后一条线
    CGContextAddLineToPoint(context, self.endPoint.x, self.endPoint.y);
    
    CGContextStrokePath(context);
    
    image=UIGraphicsGetImageFromCurrentImageContext();
    ///结束画线
    UIGraphicsEndImageContext();
    


    return image;
}
#pragma mark - 开始手势
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    ///保存所有触摸事件
    UITouch *touch=[touches anyObject];
    if (touch) {
        
        for (UIButton *button in self.buttonArray) {
            
            ///记录按键坐标
            CGPoint po=[touch locationInView:button];
            ///判断按键坐标是否在手势开始范围内，是则是选中的按钮
            if ([button pointInside:po withEvent:nil]) {
                
                [self.selectButtonArray addObject:button];
                button.highlighted=YES;
                ///保存起始坐标
                self.startPoint=button.center;
                
            }
            
        }
        
    }
}
#pragma mark - 结束手势
-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    NSMutableString *str=[[NSMutableString alloc] init];
    for (UIButton *button in self.selectButtonArray) {
        
        NSString *string=[NSString stringWithFormat:@"%ld",button.tag-100];
        
        [str appendString:string];
    }
    NSLog(@"==　手势密码===%@",str),
    self.imageView.image=nil;
    self.selectButtonArray=[[NSMutableArray alloc] init];
    for (UIButton *button in self.buttonArray) {
        button.highlighted=NO;
    }
    if (self.drawGestureBlock) {
        _drawGestureBlock(str);
    }

}
#pragma mark - 移动手势  画线过程中一直调用的方法
-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
    UITouch *touch=[touches anyObject];
    if (touch) {
        
        self.endPoint=[touch locationInView:self.imageView];
        for (UIButton *button in self.buttonArray) {
            
            CGPoint po =[touch locationInView:button];
            if ([button pointInside:po withEvent:nil]) {
                ///记录是否为重复按键
                BOOL isAdd=YES;
                for (UIButton *selectBtn in self.selectButtonArray) {
                    if (selectBtn==button) {
                        ///已选中的按钮 不再选中
                        isAdd=NO;
                        break;
                    }
                }
                if (isAdd) {
                    ///未选中的按钮 再次选中
                    [self.selectButtonArray addObject:button];
                    button.highlighted=YES;
                }
                
            }
            
        }
    }
    //每次移动过程中都要调用这个方法，把画出的图输出显示
    self.imageView.image=[self drawLine];



}




@end
