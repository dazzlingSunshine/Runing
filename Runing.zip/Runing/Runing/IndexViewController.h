//
//  IndexViewController.h
//  Runing
//
//  Created by 王佳佳 on 2017/3/2.
//  Copyright © 2017年 王佳佳. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IndexViewController : UIViewController

@end
